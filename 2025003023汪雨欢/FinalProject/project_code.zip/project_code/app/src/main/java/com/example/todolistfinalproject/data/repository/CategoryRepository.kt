package com.example.todolistfinalproject.data.repository

import com.example.todolistfinalproject.data.dao.CategoryDao
import com.example.todolistfinalproject.data.entity.CategoryEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CategoryRepository(
    private val categoryDao: CategoryDao
) {
    val allCategories: Flow<List<CategoryEntity>> = categoryDao.getAllCategories()

    suspend fun insertCategory(category: CategoryEntity) = categoryDao.insertCategory(category)

    // 改为挂起函数，避免使用 runBlocking
    suspend fun initDefaultCategories() {
        val list = categoryDao.getAllCategories().first()
        if (list.isEmpty()) {
            insertCategory(CategoryEntity(name = "默认分类"))
            insertCategory(CategoryEntity(name = "学习", color = "#03DAC6"))
            insertCategory(CategoryEntity(name = "工作", color = "#FF9800"))
        }
    }
}