package com.example.todolistfinalproject.ui.viewmodel

import com.example.todolistfinalproject.data.entity.TodoEntity
import com.example.todolistfinalproject.data.network.MockTodo

sealed interface TodoUiState {
    object Loading : TodoUiState
    data class Success(val todos: List<TodoEntity>) : TodoUiState
    data class Error(val message: String) : TodoUiState
    object Empty : TodoUiState
}

sealed interface NetworkUiState {
    object Loading : NetworkUiState
    data class Success(val todos: List<MockTodo>) : NetworkUiState
    data class Error(val message: String) : NetworkUiState
}