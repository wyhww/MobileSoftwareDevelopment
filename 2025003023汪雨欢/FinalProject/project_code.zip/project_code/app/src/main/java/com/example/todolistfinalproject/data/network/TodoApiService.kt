package com.example.todolistfinalproject.data.network

import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

// 模拟Todo数据API
data class MockTodo(
    val id: Int,
    val title: String,
    val completed: Boolean
)

interface TodoApiService {
    @GET("todos")
    suspend fun getMockTodos(): Response<List<MockTodo>>

    companion object {
        fun create(): TodoApiService {
            return Retrofit.Builder()
                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(TodoApiService::class.java)
        }
    }
}