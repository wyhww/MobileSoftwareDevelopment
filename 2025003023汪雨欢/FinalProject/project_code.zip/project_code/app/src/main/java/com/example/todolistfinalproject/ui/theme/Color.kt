package com.example.todolistfinalproject.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

val LightColorScheme = lightColorScheme(
    primary = Color(0xFFEF9A9A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFCDD2),
    onPrimaryContainer = Color(0xFFB71C1C),
    secondary = Color(0xFFE57373),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFF8A80),
    onSecondaryContainer = Color(0xFFB71C1C),
    tertiary = Color(0xFFEF5350),
    onTertiary = Color.White,
    background = Color(0xFFFFF5F5),
    onBackground = Color(0xFF1A1A2E),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1A1A2E),
    surfaceVariant = Color(0xFFFFEBEE),
    onSurfaceVariant = Color(0xFF37474F),
    error = Color(0xFFEF5350),
    onError = Color.White,
    outline = Color(0xFFEF9A9A)
)

val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFEF9A9A),
    onPrimary = Color(0xFF4A0000),
    primaryContainer = Color(0xFF7F0000),
    onPrimaryContainer = Color(0xFFFFCDD2),
    secondary = Color(0xFFE57373),
    onSecondary = Color(0xFF4A0000),
    secondaryContainer = Color(0xFF7F0000),
    onSecondaryContainer = Color(0xFFFF8A80),
    tertiary = Color(0xFFEF5350),
    onTertiary = Color(0xFF4A0000),
    background = Color(0xFF1A0A0A),
    onBackground = Color(0xFFE8E0E0),
    surface = Color(0xFF2D1B1B),
    onSurface = Color(0xFFE8E0E0),
    surfaceVariant = Color(0xFF3D2424),
    onSurfaceVariant = Color(0xFFB0A0A0),
    error = Color(0xFFEF5350),
    onError = Color(0xFF1A0A0A),
    outline = Color(0xFF7F4A4A)
)