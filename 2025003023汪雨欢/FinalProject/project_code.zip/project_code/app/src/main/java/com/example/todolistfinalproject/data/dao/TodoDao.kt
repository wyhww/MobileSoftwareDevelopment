package com.example.todolistfinalproject.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.todolistfinalproject.data.entity.TodoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TodoDao {
    @Query("SELECT * FROM todos ORDER BY createdAt DESC")
    fun getAllTodos(): Flow<List<TodoEntity>>

    @Query("SELECT * FROM todos WHERE categoryId = :categoryId ORDER BY createdAt DESC")
    fun getTodosByCategory(categoryId: Int): Flow<List<TodoEntity>>

    @Query("SELECT * FROM todos WHERE title LIKE '%' || :searchQuery || '%' ORDER BY createdAt DESC")
    fun searchTodos(searchQuery: String): Flow<List<TodoEntity>>

    @Query("""
        SELECT * FROM todos 
        WHERE categoryId = :categoryId 
        AND title LIKE '%' || :searchQuery || '%' 
        ORDER BY createdAt DESC
    """)
    fun searchTodosInCategory(categoryId: Int, searchQuery: String): Flow<List<TodoEntity>>

    // 新增：按截止日期排序（升序，最近的在前）
    @Query("SELECT * FROM todos WHERE dueDate IS NOT NULL ORDER BY dueDate ASC")
    fun getTodosByDueDate(): Flow<List<TodoEntity>>

    // 新增：获取未完成且即将到期的待办（今天及以后3天内）
    @Query("""
        SELECT * FROM todos 
        WHERE isCompleted = 0 
        AND dueDate IS NOT NULL 
        AND dueDate >= :startOfDay 
        AND dueDate <= :endOfDay 
        ORDER BY dueDate ASC
    """)
    fun getUpcomingTodos(startOfDay: Long, endOfDay: Long): Flow<List<TodoEntity>>

    @Insert
    suspend fun insertTodo(todo: TodoEntity)

    @Update
    suspend fun updateTodo(todo: TodoEntity)

    @Delete
    suspend fun deleteTodo(todo: TodoEntity)
}