package com.example.todolistfinalproject.data.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.todolistfinalproject.data.datastore.UserPreferencesRepository
import com.example.todolistfinalproject.data.repository.CategoryRepository
import com.example.todolistfinalproject.ui.screens.AddEditTodoScreen
import com.example.todolistfinalproject.ui.screens.HomeScreen
import com.example.todolistfinalproject.ui.screens.NetworkScreen
import com.example.todolistfinalproject.ui.screens.SettingsScreen
import com.example.todolistfinalproject.ui.viewmodel.TodoViewModel

@Composable
fun AppNavigation(
    viewModel: TodoViewModel,
    userPreferencesRepository: UserPreferencesRepository,
    categoryRepository: CategoryRepository
) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                navController = navController,
                viewModel = viewModel,
                categoryRepository = categoryRepository
            )
        }
        composable("settings") {
            SettingsScreen(
                navController = navController,
                userRepo = userPreferencesRepository
            )
        }
        composable("network") {
            NetworkScreen(
                navController = navController,
                viewModel = viewModel,
                categoryRepository = categoryRepository
            )
        }
        composable(
            route = "add_edit_todo/{todoId}",
            arguments = listOf(navArgument("todoId") {
                type = NavType.IntType
                defaultValue = 0
            })
        ) { backStackEntry ->
            val todoId = backStackEntry.arguments?.getInt("todoId") ?: 0
            AddEditTodoScreen(
                navController = navController,
                viewModel = viewModel,
                categoryRepository = categoryRepository,
                todoId = todoId
            )
        }
    }
}