package com.example.todolistfinalproject.data.network

import retrofit2.Response
import retrofit2.HttpException
import java.io.IOException

class NetworkDataSource(
    private val todoApiService: TodoApiService = TodoApiService.create()
) {
    suspend fun fetchMockTodos(): Result<List<MockTodo>> {
        return try {
            val response: Response<List<MockTodo>> = todoApiService.getMockTodos()
            if (response.isSuccessful) {
                Result.success(response.body() ?: emptyList())
            } else {
                Result.failure(Exception("网络请求失败: ${response.code()}"))
            }
        } catch (e: HttpException) {
            Result.failure(Exception("HTTP错误: ${e.code()}"))
        } catch (_: IOException) {
            throw Exception("网络连接错误，请检查网络")
        } catch (e: Exception) {
            Result.failure(Exception("未知错误: ${e.message}"))
        }
    }
}