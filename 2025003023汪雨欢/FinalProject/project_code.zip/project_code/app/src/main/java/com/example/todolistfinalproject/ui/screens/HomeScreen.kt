package com.example.todolistfinalproject.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.todolistfinalproject.data.entity.CategoryEntity
import com.example.todolistfinalproject.data.repository.CategoryRepository
import com.example.todolistfinalproject.ui.components.TodoItem
import com.example.todolistfinalproject.ui.viewmodel.TodoUiState
import com.example.todolistfinalproject.ui.viewmodel.TodoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: TodoViewModel,
    categoryRepository: CategoryRepository? = null
) {
    val uiState by viewModel.todoUiState.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf<Int?>(null) }
    var categories by remember { mutableStateOf<List<CategoryEntity>>(emptyList()) }
    var showSortMenu by remember { mutableStateOf(false) }
    var sortType by remember { mutableStateOf("最新创建") }

    // 加载分类
    LaunchedEffect(Unit) {
        categoryRepository?.let {
            it.allCategories.collect { list ->
                categories = list
            }
        }
    }

    // 当分类或搜索变化时重新加载
    LaunchedEffect(selectedCategoryId, searchQuery) {
        if (searchQuery.isNotBlank()) {
            viewModel.searchTodos(searchQuery)
        } else if (selectedCategoryId != null) {
            viewModel.filterByCategory(selectedCategoryId)
        } else {
            viewModel.loadTodos()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("我的待办") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                actions = {
                    // 网络数据页面
                    IconButton(onClick = { navController.navigate("network") }) {
                        Icon(
                            Icons.Default.Cloud,
                            contentDescription = "网络数据",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    // 设置页面
                    IconButton(onClick = { navController.navigate("settings") }) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "设置",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 排序按钮
                Button(
                    onClick = { showSortMenu = !showSortMenu },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary,
                        contentColor = MaterialTheme.colorScheme.onSecondary
                    )
                ) {
                    Icon(Icons.Default.Sort, contentDescription = "排序")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(sortType)
                }

                // 新增按钮
                Button(
                    onClick = { navController.navigate("add_edit_todo/0") },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("新增待办")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(16.dp)
        ) {
            // 搜索框
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { query ->
                    searchQuery = query
                },
                label = { Text("搜索待办...") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 分类筛选标签 - 使用 FilterChip
            if (categories.isNotEmpty()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // "全部"标签
                    item {
                        FilterChip(
                            onClick = {
                                selectedCategoryId = null
                                viewModel.clearFilters()
                            },
                            label = { Text("全部") },
                            selected = selectedCategoryId == null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    // 分类标签
                    items(categories) { category ->
                        FilterChip(
                            onClick = {
                                selectedCategoryId = if (selectedCategoryId == category.id) null else category.id
                            },
                            label = { Text(category.name) },
                            selected = selectedCategoryId == category.id,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // 排序菜单
            DropdownMenu(
                expanded = showSortMenu,
                onDismissRequest = { showSortMenu = false }
            ) {
                DropdownMenuItem(
                    text = { Text("最新创建") },
                    onClick = {
                        sortType = "最新创建"
                        viewModel.clearFilters()
                        showSortMenu = false
                    }
                )
                DropdownMenuItem(
                    text = { Text("截止日期") },
                    onClick = {
                        sortType = "截止日期"
                        viewModel.loadTodosSortedByDueDate()
                        showSortMenu = false
                    }
                )
                DropdownMenuItem(
                    text = { Text("即将到期") },
                    onClick = {
                        sortType = "即将到期"
                        viewModel.loadUpcomingTodos()
                        showSortMenu = false
                    }
                )
            }

            // 待办列表
            when (uiState) {
                is TodoUiState.Loading -> Text(
                    "加载中...",
                    color = MaterialTheme.colorScheme.onBackground
                )
                is TodoUiState.Empty -> {
                    Text(
                        if (searchQuery.isNotBlank()) "未找到匹配的待办" else "暂无待办，点击下方按钮添加",
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                is TodoUiState.Error -> Text(
                    "错误：${(uiState as TodoUiState.Error).message}",
                    color = MaterialTheme.colorScheme.error
                )
                is TodoUiState.Success -> {
                    val list = (uiState as TodoUiState.Success).todos
                    if (list.isEmpty()) {
                        Text(
                            if (searchQuery.isNotBlank()) "未找到匹配的待办" else "暂无待办",
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(list) { todo ->
                                TodoItem(
                                    todo = todo,
                                    onTodoClick = {
                                        navController.navigate("add_edit_todo/${todo.id}")
                                    },
                                    onStatusToggle = {
                                        viewModel.toggleTodoStatus(todo)
                                    },
                                    onDelete = {
                                        viewModel.deleteTodo(todo)
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}