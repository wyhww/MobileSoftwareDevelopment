package com.example.todolistfinalproject.data.repository

import com.example.todolistfinalproject.data.dao.TodoDao
import com.example.todolistfinalproject.data.entity.TodoEntity
import com.example.todolistfinalproject.data.network.NetworkDataSource
import com.example.todolistfinalproject.data.network.MockTodo
import kotlinx.coroutines.flow.Flow

class TodoRepository(
    private val todoDao: TodoDao,
    private val networkDataSource: NetworkDataSource = NetworkDataSource()
) {
    // 本地数据操作
    fun getAllTodos(): Flow<List<TodoEntity>> = todoDao.getAllTodos()
    fun searchTodos(query: String): Flow<List<TodoEntity>> = todoDao.searchTodos(query)
    fun getTodosByCategory(categoryId: Int): Flow<List<TodoEntity>> = todoDao.getTodosByCategory(categoryId)
    fun searchTodosInCategory(categoryId: Int, query: String): Flow<List<TodoEntity>> =
        todoDao.searchTodosInCategory(categoryId, query)
    fun getTodosByDueDate(): Flow<List<TodoEntity>> = todoDao.getTodosByDueDate()
    fun getUpcomingTodos(startOfDay: Long, endOfDay: Long): Flow<List<TodoEntity>> =
        todoDao.getUpcomingTodos(startOfDay, endOfDay)

    suspend fun insertTodo(todo: TodoEntity) = todoDao.insertTodo(todo)
    suspend fun updateTodo(todo: TodoEntity) = todoDao.updateTodo(todo)
    suspend fun deleteTodo(todo: TodoEntity) = todoDao.deleteTodo(todo)

    suspend fun fetchMockTodos() = networkDataSource.fetchMockTodos()

    // 支持指定分类ID保存网络数据
    suspend fun saveMockTodosToLocal(mockTodos: List<MockTodo>, categoryId: Int = 1) {
        mockTodos.take(10).forEach { mockTodo ->
            val todo = TodoEntity(
                title = mockTodo.title,
                content = "从网络获取的待办项",
                categoryId = categoryId,
                isCompleted = mockTodo.completed,
                createdAt = System.currentTimeMillis()
            )
            todoDao.insertTodo(todo)
        }
    }
}