package com.example.todolistfinalproject.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.todolistfinalproject.data.entity.TodoEntity
import com.example.todolistfinalproject.data.network.MockTodo
import com.example.todolistfinalproject.data.repository.TodoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class TodoViewModel(
    private val todoRepository: TodoRepository
) : ViewModel() {
    // 本地Todo列表状态
    private val _todoUiState = MutableStateFlow<TodoUiState>(TodoUiState.Loading)
    val todoUiState: StateFlow<TodoUiState> = _todoUiState.asStateFlow()

    // 网络数据状态
    private val _networkUiState = MutableStateFlow<NetworkUiState>(NetworkUiState.Loading)
    val networkUiState: StateFlow<NetworkUiState> = _networkUiState.asStateFlow()

    // 当前选中的分类ID（null 表示全部）
    private var currentCategoryId: Int? = null
    // 当前搜索关键词
    private var currentSearchQuery: String = ""

    init {
        loadTodos()
    }

    // 加载本地待办列表
    fun loadTodos() {
        viewModelScope.launch {
            if (currentCategoryId != null && currentSearchQuery.isNotBlank()) {
                todoRepository.searchTodosInCategory(currentCategoryId!!, currentSearchQuery).collect { todos ->
                    updateUiState(todos)
                }
            } else if (currentCategoryId != null) {
                todoRepository.getTodosByCategory(currentCategoryId!!).collect { todos ->
                    updateUiState(todos)
                }
            } else if (currentSearchQuery.isNotBlank()) {
                todoRepository.searchTodos(currentSearchQuery).collect { todos ->
                    updateUiState(todos)
                }
            } else {
                todoRepository.getAllTodos().collect { todos ->
                    updateUiState(todos)
                }
            }
        }
    }

    private fun updateUiState(todos: List<TodoEntity>) {
        _todoUiState.update {
            if (todos.isEmpty()) {
                TodoUiState.Empty
            } else {
                TodoUiState.Success(todos)
            }
        }
    }

    // 按分类筛选
    fun filterByCategory(categoryId: Int?) {
        currentCategoryId = categoryId
        loadTodos()
    }

    // 搜索待办
    fun searchTodos(query: String) {
        currentSearchQuery = query
        loadTodos()
    }

    // 按截止日期排序
    fun loadTodosSortedByDueDate() {
        viewModelScope.launch {
            todoRepository.getTodosByDueDate().collect { todos ->
                updateUiState(todos)
            }
        }
    }

    // 获取即将到期的待办（最近3天）
    fun loadUpcomingTodos() {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val threeDaysLater = now + 3 * 24 * 60 * 60 * 1000L
            todoRepository.getUpcomingTodos(now, threeDaysLater).collect { todos ->
                updateUiState(todos)
            }
        }
    }

    // 清除筛选条件，恢复全部
    fun clearFilters() {
        currentCategoryId = null
        currentSearchQuery = ""
        loadTodos()
    }

    // 新增/编辑待办
    fun saveTodo(todo: TodoEntity) {
        viewModelScope.launch {
            if (todo.id == 0) {
                todoRepository.insertTodo(todo)
            } else {
                todoRepository.updateTodo(todo)
            }
            loadTodos()
        }
    }

    // 删除待办
    fun deleteTodo(todo: TodoEntity) {
        viewModelScope.launch {
            todoRepository.deleteTodo(todo)
            loadTodos()
        }
    }

    // 切换待办完成状态
    fun toggleTodoStatus(todo: TodoEntity) {
        viewModelScope.launch {
            todoRepository.updateTodo(todo.copy(isCompleted = !todo.isCompleted))
            loadTodos()
        }
    }

    // 获取网络待办数据
    fun fetchMockTodos() {
        viewModelScope.launch {
            _networkUiState.value = NetworkUiState.Loading
            val result = todoRepository.fetchMockTodos()

            result.onSuccess { mockTodoList: List<MockTodo> ->
                _networkUiState.value = NetworkUiState.Success(todos = mockTodoList)
            }.onFailure { throwable ->
                val errorMsg = throwable.message ?: "未知错误"
                _networkUiState.value = NetworkUiState.Error(errorMsg)
            }
        }
    }

    // 保存网络数据到本地（支持指定分类）
    fun saveMockTodosToLocal(mockTodos: List<MockTodo>, categoryId: Int = 1) {
        viewModelScope.launch {
            todoRepository.saveMockTodosToLocal(mockTodos, categoryId)
            loadTodos()
        }
    }
}