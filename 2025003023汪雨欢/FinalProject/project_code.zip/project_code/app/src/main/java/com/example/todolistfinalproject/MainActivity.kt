package com.example.todolistfinalproject

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.example.todolistfinalproject.data.database.AppDatabase
import com.example.todolistfinalproject.data.datastore.UserPreferencesRepository
import com.example.todolistfinalproject.data.navigation.AppNavigation
import com.example.todolistfinalproject.data.repository.CategoryRepository
import com.example.todolistfinalproject.data.repository.TodoRepository
import com.example.todolistfinalproject.ui.theme.TodoListFinalProjectTheme
import com.example.todolistfinalproject.ui.viewmodel.TodoViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val database by lazy { AppDatabase.getDatabase(this) }
    private val todoRepository by lazy { TodoRepository(database.todoDao()) }
    private val categoryRepository by lazy { CategoryRepository(database.categoryDao()) }
    private val userPreferencesRepository by lazy { UserPreferencesRepository(this) }
    private val todoViewModel by lazy { TodoViewModel(todoRepository) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 初始化默认分类
        lifecycleScope.launch {
            categoryRepository.initDefaultCategories()
        }

        setContent {
            TodoListFinalProjectTheme(
                userPreferencesRepository = userPreferencesRepository,
                dynamicColor = false
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation(
                        viewModel = todoViewModel,
                        userPreferencesRepository = userPreferencesRepository,
                        categoryRepository = categoryRepository
                    )
                }
            }
        }
    }
}