package com.example.todolistfinalproject.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.todolistfinalproject.data.datastore.UserPreferencesRepository

@Composable
fun TodoListFinalProjectTheme(
    darkTheme: Boolean? = null,
    followSystem: Boolean = true,
    dynamicColor: Boolean = false,
    userPreferencesRepository: UserPreferencesRepository,
    content: @Composable () -> Unit
) {
    val darkModeFlow = userPreferencesRepository.darkModeFlow.collectAsStateWithLifecycle(initialValue = false)
    val followSystemFlow = userPreferencesRepository.followSystemFlow.collectAsStateWithLifecycle(initialValue = true)

    val useDarkTheme = when {
        !followSystemFlow.value -> darkModeFlow.value
        darkTheme != null -> darkTheme
        else -> isSystemInDarkTheme()
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (useDarkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        useDarkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}