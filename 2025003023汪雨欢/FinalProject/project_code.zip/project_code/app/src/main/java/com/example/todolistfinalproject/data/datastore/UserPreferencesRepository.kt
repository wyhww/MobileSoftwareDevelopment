package com.example.todolistfinalproject.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

class UserPreferencesRepository(private val context: Context) {
    private val darkModeKey = booleanPreferencesKey("dark_mode")
    private val followSystemKey = booleanPreferencesKey("follow_system")

    val darkModeFlow: Flow<Boolean> = context.dataStore.data
        .map { prefs ->
            prefs[darkModeKey] ?: false
        }

    val followSystemFlow: Flow<Boolean> = context.dataStore.data
        .map { prefs ->
            prefs[followSystemKey] ?: true
        }

    suspend fun setDarkMode(enable: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[darkModeKey] = enable
            prefs[followSystemKey] = false
        }
    }

    suspend fun setFollowSystem(enable: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[followSystemKey] = enable
        }
    }
}